# ChatAPI
APIs for a Chat app. Written with Django Rest framework and Django channels.

The documentation for the http end points can be found [here](https://documenter.getpostman.com/view/15225360/TzzEouP9)

This is the format of message the websocket accepts on connection
![Screenshot (86).png](https://cdn.hashnode.com/res/hashnode/image/upload/v1629941911315/hFbK0VYxi.png)

Please Leave a star!